from tkinter import *
from tkinter import messagebox
from string import ascii_uppercase
from adjacency_matrix import *
from math import inf

import numpy as np
import networkx as nx
import matplotlib.pyplot as plt

from pprint import pprint


def handle_reset_adjacency_maxtrix_button(vars_checkbox):
    def inner():
        for row in vars_checkbox:
            for col in row:
                col.set(0)

    return inner

def handle_adjacency_maxtrix_button(root, var_dimention, vars_checkbox):
    def inner():
        master = Toplevel(root)
        master.title("")
        root.resizable(width=False, height=False)

        for i in range(var_dimention.get()):
            for j in range(var_dimention.get()):
                Checkbutton(master, variable=vars_checkbox[i][j], onvalue=1, offvalue=0).grid(row=i + 1, column=j + 1)
                if i == 0:
                    Label(master,text=ascii_uppercase[j]).grid(row=i, column=j + 1)
                if j == 0:
                    Label(master, text=ascii_uppercase[i]).grid(row=i + 1, column=j)

        Button(master, text="Cбросить", command=handle_reset_adjacency_maxtrix_button(vars_checkbox)).grid(columnspan=var_dimention.get() + 1)

        master.mainloop()

    return inner

def handle_start_button(root, var_dimention, vars_checkbox):
    def inner():
        labels = {}
        adjacency_matrix = [] # матрица связности
        node_color_map = ['white' for _ in range(var_dimention.get())] # карта цветов для узлов
        
        G = nx.Graph() # создаём граф


        for i in vars_checkbox[0:var_dimention.get()]:
            adjacency_matrix.append([j.get() for j in i[0:var_dimention.get()]])

        if adjacency_matrix_is_empty(adjacency_matrix):
            messagebox.showerror("Ошибка", "Матрица смежности не заполнена.")
            return
        
        for i in range(var_dimention.get()):
            labels[i] = f"${ascii_uppercase[i]}$"

        adjacency_matrix = np.array(adjacency_matrix)

        rows, cols = np.where(adjacency_matrix == 1)
        edges = zip(rows.tolist(), cols.tolist())

        G.add_edges_from(edges)

        if nx.check_planarity(G, counterexample=False) == (False, None):
            messagebox.showerror("Ошибка", "Граф не планарный.")
            return

        d = nx.coloring.greedy_color(G, strategy='connected_sequential_bfs', interchange=True) # тут красим 
        node_color_map = list(d.values())
        pos = nx.spring_layout(G, iterations=200)

        nx.draw(G, pos=pos, with_labels=True, node_color=node_color_map, labels=labels, cmap=plt.cm.gnuplot2)
        plt.show()
    

    return inner

