import matplotlib.pyplot as plt
from pprint import pprint
import networkx as nx
import numpy as np

G = nx.DiGraph()

adjacency_matrix = np.array([[ 0, 0, 0, 0, 0 ,0 ,1, 0, 0,0,0],
                             [ 1, 1, 0, 0, 0 ,0 ,0, 1, 0,0,1],
                             [ 0, 0, 1, 1, 0 ,0 ,0, 0, 1,1,0],
                             [ 0, 0, 0, 1, 1 ,0 ,0, 0, 0,0,0],
                             [ 0, 0, 0, 1, 0 ,0 ,0, 0, 0,0,0],
                             [ 0, 0, 0, 0, 0 ,1 ,0, 1, 0,0,0],
                             [ 0, 0, 0, 0, 0 ,0 ,0, 0, 0,0,1],
                             [ 0, 0, 0, 0, 0 ,0 ,0, 0, 0,0,0],
                             [ 0, 0, 1, 0, 0 ,0 ,0, 0, 0,0,0],
                             [ 1, 0, 0, 1, 1 ,0 ,0, 0, 1,0,0],
                             [ 0, 0, 0, 0, 1 ,1 ,0, 0, 0,0,1]])

labels={}
labels[0]=r'$a$'
labels[1]=r'$b$'
labels[2]=r'$c$'
labels[3]=r'$d$'
labels[4]=r'$e$'
labels[5]=r'$f$'
labels[6]=r'$g$'
labels[7]=r'$h$'
labels[8]=r'$i$'
labels[9]=r'$j$'
labels[10]=r'$k$'

rows, cols = np.where(adjacency_matrix == 1)
edges = zip(rows.tolist(), cols.tolist())

# pprint(list(edges))

G.add_edges_from(edges)

# nx.draw(G)
# nx.draw_random(G)
# nx.draw_circular(G)
# nx.draw_networkx(G, labels=labels ,with_labels=True, pos=nx.shell_layout(G))
# plt.show()

d = nx.coloring.equitable_color(G, num_colors=var_dimention.get() + 1)
